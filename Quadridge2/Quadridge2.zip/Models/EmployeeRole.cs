﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quadridge2.Models
{
    public static class EmployeeRole
    {
        public const string Employee = "Employee";
    }
}